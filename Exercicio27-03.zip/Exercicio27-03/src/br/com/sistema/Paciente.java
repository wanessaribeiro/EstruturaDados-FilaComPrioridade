package br.com.sistema;

public class Paciente implements Comparable<Paciente>{
	
	public static final int AZUL = 4;
	public static final int VERDE = 3;
	public static final int AMARELO = 2;
	public static final int VERMELHO = 1;

	String nome, pressao, email, temperatura, sintomas;
	public int condicao;
	
	public Paciente(String nome, String pressao, String email, String temperatura, String sintomas, int condicao) {
		
		this.nome = nome;
		this.pressao = pressao;
		this.email = email;
		this.temperatura = temperatura;
		this.sintomas = sintomas;
		this.condicao = condicao;
	}

	@Override
	public int compareTo(Paciente p) {
		if(this.condicao > p.condicao) return 1;
		if(this.condicao < p.condicao) return -1;
		return 0;
	}

	@Override
	public String toString() {
		return "Paciente [nome=" + nome + ", pressao=" + pressao + ", email=" + email + ", temperatura=" + temperatura
				+ ", sintomas=" + sintomas + "]";
	}
	
	
}
