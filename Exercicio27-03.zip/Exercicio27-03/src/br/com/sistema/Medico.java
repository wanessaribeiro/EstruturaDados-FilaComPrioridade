package br.com.sistema;

public class Medico {

	public String nome;
	public String crm;
	public String especialidade;
	public String usuario;
	public String senha;
	
	public Medico(String nome, String crm, String especialidade, String usuario, String senha){
		
		this.nome = nome;
		this.crm = crm;
		this.especialidade = especialidade;
		this.usuario = usuario;
		this.senha = senha;
	}
		
}
