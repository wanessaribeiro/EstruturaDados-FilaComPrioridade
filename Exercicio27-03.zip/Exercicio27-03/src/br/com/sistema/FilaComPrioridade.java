package br.com.sistema;

public class FilaComPrioridade<T> extends Fila<T> {

	public void enfileira(T elemento) {
		
		Comparable<T> prioridade = (Comparable<T>) elemento;
		
		int i = 0;
		for (i = 0; i < this.tamanho; i++) {
			
			if(prioridade.compareTo(this.elementos[i]) < 0) {
				
				break;
			}
		}
		
		this.adiciona(i, elemento);
	}
	
}
