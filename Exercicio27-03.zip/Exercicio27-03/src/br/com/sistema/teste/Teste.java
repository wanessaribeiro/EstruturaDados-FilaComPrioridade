package br.com.sistema.teste;

import java.util.Scanner;

import br.com.sistema.FilaComPrioridade;
import br.com.sistema.Medico;
import br.com.sistema.Paciente;

public class Teste {

	public static void main(String[] args) {
		
		Paciente joana = new Paciente("Joana Jardim", "12/8", "joaninhadojardim@hotmail.com", "34", "Fratura no bra�o e Tosse", Paciente.AMARELO);
		Paciente luciano = new Paciente("Luciano Luck", "12/8", "luciabo@hotmail.com", "36", "Dor no corpo ", Paciente.VERDE);
		Paciente carlos = new Paciente("Carlos J�o", "14/8", "carlindoidao@hotmail.com", "34", "Tosse Forte", Paciente.VERDE);
		Paciente alfredo = new Paciente("Alfreddo Neves", "12/8", "alf_o_eteimoso@hotmail.com", "38", "Fratura na perna, Fratura em tr�s costelas, Fratura no bra�o", Paciente.VERMELHO);

		FilaComPrioridade<Paciente> filinha = new FilaComPrioridade<Paciente>();
		FilaComPrioridade<Medico>fila = new FilaComPrioridade<Medico>();
		
		filinha.enfileira(joana);
		filinha.enfileira(luciano);
		filinha.enfileira(carlos);
		filinha.enfileira(alfredo);
		
		System.out.println(filinha);
	
		int op = 0, operador = 0, medico = 0;
		System.out.println("1.Entrar como operador");
		System.out.println("2.Entrar como m�dico");
		System.out.println("-> ");
		Scanner scan = new Scanner(System.in);
		op = scan.nextInt();
		String nome, pressao, email, temperatura, sintomas, crm, especialidade, usuario, senha;
		int prioridade;
		
		switch (op) {
		case 1:
			
			System.out.println("1.Cadastrar paciente");
			System.out.println("2.Cadastrar m�dico");
			System.out.println("-> ");
			operador = scan.nextInt();
			switch(operador) {
			case 1:
				
				System.out.print("Nome: ");
				nome = scan.next();
				System.out.println("Press�o: ");
				pressao = scan.next();
				System.out.println("Email: ");
				email = scan.next();
				System.out.print("Temperatura: ");
				temperatura = scan.next();
				System.out.println("Sintomas: ");
				sintomas = scan.next();
				System.out.print("Prioridade: ");
				prioridade = scan.nextInt();
				
				filinha.enfileira(new Paciente(nome, pressao, email, temperatura, sintomas, prioridade));
				break;
			case 2:
				
				System.out.print("Nome: ");
				nome = scan.next();
				System.out.print("CRM: ");
				crm = scan.next();
				System.out.print("Especialidade: ");
				especialidade = scan.next();
				System.out.print("Usuario: ");
				usuario = scan.next();
				System.out.print("Senha: ");
				senha = scan.nextLine();
				
				fila.enfileira(new Medico(nome, crm, especialidade, usuario, senha));
				break;
			default:
				break;
			}
			
			break;

		case 2:
			
			System.out.println("1.Chamar um paciente");
			System.out.println("2.Ver fila");
			System.out.println("-> ");
			operador = scan.nextInt();
			switch(medico) {
			case 1:
				
				System.out.println(filinha.desenfileira());
				break;
			case 2:
				
				System.out.println(filinha);
				break;
			default:
				break;
			}
			
			break;
		default:
			break;
		}
		
	}

}
